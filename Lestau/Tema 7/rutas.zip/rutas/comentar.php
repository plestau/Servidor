<HTML>
<HEAD><TITLE>Actividad 1 - Unidad 7 - Curso Iniciación de PHP 5 - Rutas Senderismo</TITLE>
</HEAD>

<BODY bgcolor="#C0C0C0" link="black" vlink="black" alink="black">
<CENTER>

<TABLE border="0" align="center" cellspacing="3" cellpadding="3" width="760" bgcolor="green">
<TR>
	<TD><a href="index.php" ><img src=senderismo.png width=240 height=70></a></TD>
	<TH colspan="2" width="75%">&nbsp;
		<FONT size="6" color="black" face="arial, helvetica"><u>Rutas senderismo</u></FONT>&nbsp
	</TH>
</TR></TABLE><P>
          </TR></TABLE><P><A NAME='ancla'></A><FONT color='green'><h2><u>COMENTAR RUTA</u></h2></FONT><TABLE BORDER='0' cellspacing='10' cellpadding='0' align='center' width='600'><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>T&iacute;tulo</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>Descripci&oacute;n</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>Desnivel (m)</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>Distancia (Km)</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>Dificultad</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR><TR><TD bgcolor='green' align=center width=140>
    			<FONT color='white'>Notas</FONT>
    		 	  </TD><TD><FONT><B></B></FONT></TD>
    		</TR></TABLE><TABLE BORDER='0' cellspacing='1' cellpadding='1' align='center' width='800'>
   	          <TR>
   	      	    <TH bgcolor='green'><FONT color='white'>Nombre</FONT></TH>
   	      	    <TH bgcolor='green'><FONT color='white'>Fecha</FONT></TH>
   	      	    <TH bgcolor='green'><FONT color='white'>Comentario</FONT></TH>   	      	
   	          </TR><FORM name='form9' method='post' action="index.php?operacion=add_comentario"><TR>
   		   <TD><input type='text' name='nombre' size='20' maxlength='50'></TD>
   		   <TD><FONT size='-1'><B></B></FONT></TD>
   		   <TD align=right><INPUT type='text' name='texto' size='75' maxlength='254'>
   		  		   <INPUT type='hidden' NAME='id' value = '214'>
   				   <INPUT TYPE='SUBMIT' NAME='pulsa' VALUE="Añadir"></TD> 
   	           </TR></FORM></TABLE><P>
</BODY>
</HTML>

